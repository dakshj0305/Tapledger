# VOLTURA v26.1.2 — GSAP Finance Motion

Integrated source bundle for the feature branch. Includes updated app source, GSAP plugins, third-party notice and implementation notes. Existing GSAP core and ScrollTrigger are not duplicated. No user financial data or backups are included.
