# VOLTURA v26.1.2 — GSAP Finance Motion

Final integrated source bundle merged to the default branch. Extract at the repository root to review the included source files.

Includes:
- Updated HTML entry page, app logic, runtime CSS, and GSAP motion controller.
- Service-worker cache updates.
- Local GSAP 3.15.1 DrawSVGPlugin, MotionPathPlugin and Flip.
- Third-party notice and implementation notes.

Existing GSAP core and ScrollTrigger remain in the repository and are not duplicated in this archive. No user financial records or backup data are included.
